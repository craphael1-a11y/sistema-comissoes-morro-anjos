import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { authenticateUser, registerUser, generateToken } from "./_core/auth";

const COOKIE_NAME = "auth_token";

/**
 * Retorna a taxa de comissão baseada no cargo
 * - Gerente: 1% (100)
 * - Consultor/Supervisor: 2% (200)
 * - Promotor: 1.5% (150)
 */
function getTaxaComissaoPorCargo(cargo: "gerente" | "consultor" | "supervisor" | "promotor"): number {
  const taxas = {
    gerente: 100,      // 1%
    consultor: 200,    // 2%
    supervisor: 200,   // 2%
    promotor: 150,     // 1.5%
  };
  return taxas[cargo];
}

/**
 * Calcula as parcelas de comissão baseado na lógica de negócio:
 * - Comissão = 2% do valor total da venda
 * - Número de parcelas = número de parcelas da entrada do cliente
 * - Cada parcela tem vencimento mensal
 */
function calcularParcelas(
  valorTotal: number,
  taxaComissao: number,
  parcelasEntrada: number,
  dataVenda: Date
): Array<{ numeroParcela: number; valorParcela: number; dataVencimento: Date }> {
  const valorComissaoTotal = Math.round((valorTotal * taxaComissao) / 10000);
  const valorParcela = Math.round(valorComissaoTotal / parcelasEntrada);
  const diferenca = valorComissaoTotal - (valorParcela * parcelasEntrada);

  const parcelas = [];
  for (let i = 1; i <= parcelasEntrada; i++) {
    // Função auxiliar para adicionar meses corretamente
    // Evita o bug do setMonth() quando o dia > dias do mês de destino
    // Exemplo: 30 jan + 1 mês = 28 fev (não 2 mar)
    const adicionarMeses = (data: Date, meses: number): Date => {
      const diaOriginal = data.getDate();
      const mesOriginal = data.getMonth();
      const anoOriginal = data.getFullYear();
      
      // Calcula o novo mês e ano
      let novoMes = mesOriginal + meses;
      let novoAno = anoOriginal;
      
      // Ajusta para overflow de meses
      while (novoMes > 11) {
        novoMes -= 12;
        novoAno += 1;
      }
      
      // Calcula quantos dias tem o novo mês
      // Cria uma data no primeiro dia do próximo mês e volta um dia
      const ultimoDiaDoMes = new Date(novoAno, novoMes + 1, 0).getDate();
      
      // Se o dia original é maior que o último dia do novo mês,
      // usa o último dia do mês
      const diaFinal = Math.min(diaOriginal, ultimoDiaDoMes);
      
      return new Date(novoAno, novoMes, diaFinal);
    };

    // Primeira parcela vence no mês seguinte
    // Ex: venda em 30/11 -> parcela 1 vence em 30/12, parcela 2 em 30/01, etc
    const dataVencimento = adicionarMeses(dataVenda, i);

    // Adiciona a diferença de arredondamento na última parcela
    const valor = i === parcelasEntrada ? valorParcela + diferenca : valorParcela;

    parcelas.push({
      numeroParcela: i,
      valorParcela: valor,
      dataVencimento,
    });
  }

  return parcelas;
}

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    register: publicProcedure
      .input(z.object({
        username: z.string().min(3).max(50),
        password: z.string().min(6),
        name: z.string().min(1),
        email: z.string().email().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const user = await registerUser(input.username, input.password, input.name, input.email);
        
        const token = generateToken(user.id, user.username);
        
        ctx.res.cookie(COOKIE_NAME, token, {
          httpOnly: true,
          secure: ctx.req.protocol === "https",
          sameSite: ctx.req.protocol === "https" ? "none" : "lax",
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias
          path: "/",
        });

        return { success: true, user };
      }),

    login: publicProcedure
      .input(z.object({
        username: z.string(),
        password: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const user = await authenticateUser(input.username, input.password);
        
        if (!user) {
          throw new Error("Usuário ou senha inválidos");
        }

        const token = generateToken(user.id, user.username);
        
        ctx.res.cookie(COOKIE_NAME, token, {
          httpOnly: true,
          secure: ctx.req.protocol === "https",
          sameSite: ctx.req.protocol === "https" ? "none" : "lax",
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias
          path: "/",
        });

        return { success: true, user };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, {
        httpOnly: true,
        secure: ctx.req.protocol === "https",
        sameSite: ctx.req.protocol === "https" ? "none" : "lax",
        path: "/",
      });
      return { success: true } as const;
    }),
  }),

  vendas: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getVendasByUsuario(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getVendaById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        codigo: z.string().min(1),
        clienteNome: z.string().optional(),
        cargo: z.enum(["gerente", "consultor", "supervisor", "promotor"]),
        valorTotal: z.number().positive(),
        percentualEntrada: z.number().min(1).max(100),
        parcelasEntrada: z.number().min(1).max(10),
        dataVenda: z.date(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Calcula taxa de comissão baseada no cargo
        const taxaComissao = getTaxaComissaoPorCargo(input.cargo);
        
        // Calcula valor total da comissão
        const valorComissaoTotal = Math.round((input.valorTotal * taxaComissao) / 10000);

        // Cria a venda
        const vendaResult = await db.createVenda({
          codigo: input.codigo,
          clienteNome: input.clienteNome || null,
          cargo: input.cargo,
          valorTotal: input.valorTotal,
          percentualEntrada: input.percentualEntrada,
          parcelasEntrada: input.parcelasEntrada,
          taxaComissao,
          valorComissaoTotal,
          status: "ativa",
          dataVenda: input.dataVenda,
          observacoes: input.observacoes || null,
          usuarioId: ctx.user.id, // Usa o ID do usuário autenticado
        });

        const vendaId = Number((vendaResult as any)[0]?.insertId || vendaResult);

        // Calcula e cria as parcelas
        const parcelasCalculadas = calcularParcelas(
          input.valorTotal,
          taxaComissao,
          input.parcelasEntrada,
          input.dataVenda
        );

        for (const parcela of parcelasCalculadas) {
          await db.createParcela({
            vendaId,
            numeroParcela: parcela.numeroParcela,
            valorParcela: parcela.valorParcela,
            dataVencimento: parcela.dataVencimento,
            status: "pendente",
          });
        }

        return { vendaId, success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        codigo: z.string().optional(),
        clienteNome: z.string().optional(),
        valorTotal: z.number().positive().optional(),
        cargo: z.enum(["gerente", "consultor", "supervisor", "promotor"]).optional(),
        parcelasEntrada: z.number().min(1).max(10).optional(),
        dataVenda: z.date().optional(),
        observacoes: z.string().optional(),
        status: z.enum(["ativa", "cancelada", "concluida"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        
        const venda = await db.getVendaById(id);
        if (!venda || venda.usuarioId !== ctx.user.id) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Voce nao tem permissao para editar esta venda',
          });
        }
        
        if (data.valorTotal !== undefined || data.parcelasEntrada !== undefined || data.dataVenda !== undefined) {
          const parcelas = await db.getParcelasByVenda(id);
          for (const parcela of parcelas) {
            await db.updateParcela(parcela.id, { status: 'cancelada' });
          }
          
          const valorTotal = data.valorTotal ?? venda.valorTotal;
          const parcelasEntrada = data.parcelasEntrada ?? venda.parcelasEntrada;
          const dataVenda = data.dataVenda ?? venda.dataVenda;
          const cargo = data.cargo ?? venda.cargo;
          
          const taxaComissao = getTaxaComissaoPorCargo(cargo as any);
          const parcelasCalculadas = calcularParcelas(valorTotal, taxaComissao, parcelasEntrada, dataVenda);
          
          for (const parcela of parcelasCalculadas) {
            await db.createParcela({
              vendaId: id,
              numeroParcela: parcela.numeroParcela,
              valorParcela: parcela.valorParcela,
              dataVencimento: parcela.dataVencimento,
              status: 'pendente',
            });
          }
          
          const novaComissaoTotal = Math.round((valorTotal * taxaComissao) / 10000);
          (data as any).valorComissaoTotal = novaComissaoTotal;
        }
        
        await db.updateVenda(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteVenda(input.id);
        return { success: true };
      }),

    simular: protectedProcedure
      .input(z.object({
        cargo: z.enum(["gerente", "consultor", "supervisor", "promotor"]),
        valorTotal: z.number().positive(),
        percentualEntrada: z.number().min(1).max(100),
        parcelasEntrada: z.number().min(1).max(10),
        dataVenda: z.date().optional(),
      }))
      .query(({ input }) => {
        const taxaComissao = getTaxaComissaoPorCargo(input.cargo);
        const dataBase = input.dataVenda || new Date();
        const parcelas = calcularParcelas(
          input.valorTotal,
          taxaComissao,
          input.parcelasEntrada,
          dataBase
        );

        const valorComissaoTotal = parcelas.reduce((sum, p) => sum + p.valorParcela, 0);

        return {
          cargo: input.cargo,
          valorTotal: input.valorTotal,
          percentualEntrada: input.percentualEntrada,
          parcelasEntrada: input.parcelasEntrada,
          taxaComissao,
          valorComissaoTotal,
          parcelas,
        };
      }),
  }),

  parcelas: router({
    getByVenda: protectedProcedure
      .input(z.object({ vendaId: z.number() }))
      .query(async ({ input }) => {
        return await db.getParcelasByVenda(input.vendaId);
      }),

    marcarRecebida: protectedProcedure
      .input(z.object({
        id: z.number(),
        dataRecebimento: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const data = input.dataRecebimento || new Date();
        await db.marcarParcelaRecebida(input.id, data);
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pendente", "recebida", "atrasada", "cancelada", "inadimplente"]).optional(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateParcela(id, data);
        return { success: true };
      }),

    listPendentes: protectedProcedure.query(async ({ ctx }) => {
      return await db.getParcelasPendentes(ctx.user.id);
    }),

    listPorPeriodo: protectedProcedure
      .input(z.object({
        dataInicio: z.date(),
        dataFim: z.date(),
      }))
      .query(async ({ input }) => {
        return await db.getParcelasPorPeriodo(input.dataInicio, input.dataFim);
      }),
  }),

  dashboard: router({
    estatisticas: protectedProcedure.query(async ({ ctx }) => {
      const [estatisticasVendas, estatisticasParcelas] = await Promise.all([
        db.getEstatisticasGerais(ctx.user.id),
        db.getEstatisticasParcelas(ctx.user.id),
      ]);

      return {
        vendas: estatisticasVendas,
        parcelas: estatisticasParcelas,
      };
    }),
  }),

  metas: router({
    get: protectedProcedure
      .input(z.object({
        mes: z.number().min(1).max(12),
        ano: z.number().min(2020).max(2100),
      }))
      .query(async ({ input, ctx }) => {
        const meta = await db.getMeta(ctx.user.id, input.mes, input.ano);
        const vendas = await db.getVendasPorMes(ctx.user.id, input.mes, input.ano);
        return {
          meta,
          vendas,
        };
      }),

    list: protectedProcedure
      .input(z.object({
        ano: z.number().optional(),
      }).optional())
      .query(async ({ input, ctx }) => {
        return await db.getMetasByUsuario(ctx.user.id, input?.ano);
      }),

    save: protectedProcedure
      .input(z.object({
        mes: z.number().min(1).max(12),
        ano: z.number().min(2020).max(2100),
        metaVendas: z.number().min(0),
        metaQuantidade: z.number().min(0).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.createOrUpdateMeta(
          ctx.user.id,
          input.mes,
          input.ano,
          input.metaVendas,
          input.metaQuantidade
        );
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteMeta(input.id);
        return { success: true };
      }),

    projecao: protectedProcedure
      .input(z.object({
        mes: z.number().min(1).max(12),
        ano: z.number().min(2020).max(2100),
      }))
      .query(async ({ input, ctx }) => {
        // Busca dados dos últimos 3 meses para calcular média
        const mesesAnteriores = [];
        for (let i = 1; i <= 3; i++) {
          let mes = input.mes - i;
          let ano = input.ano;
          if (mes <= 0) {
            mes += 12;
            ano -= 1;
          }
          const vendas = await db.getVendasPorMes(ctx.user.id, mes, ano);
          mesesAnteriores.push(vendas);
        }

        // Calcula média
        const mediaVendido = mesesAnteriores.reduce((sum, m) => sum + Number(m.totalVendido || 0), 0) / 3;
        const mediaQuantidade = mesesAnteriores.reduce((sum, m) => sum + Number(m.quantidade || 0), 0) / 3;

        // Dados do mês atual
        const mesAtual = await db.getVendasPorMes(ctx.user.id, input.mes, input.ano);
        const meta = await db.getMeta(ctx.user.id, input.mes, input.ano);

        // Calcula dias restantes no mês
        const hoje = new Date();
        const ultimoDiaMes = new Date(input.ano, input.mes, 0).getDate();
        const diasPassados = hoje.getMonth() + 1 === input.mes && hoje.getFullYear() === input.ano ? hoje.getDate() : 0;
        const diasRestantes = ultimoDiaMes - diasPassados;

        // Projeção baseada no ritmo atual
        const ritmoAtual = diasPassados > 0 ? Number(mesAtual.totalVendido || 0) / diasPassados : 0;
        const projecaoMes = ritmoAtual * ultimoDiaMes;

        return {
          mediaVendido: Math.round(mediaVendido),
          mediaQuantidade: Math.round(mediaQuantidade),
          mesAtual: {
            totalVendido: Number(mesAtual.totalVendido || 0),
            quantidade: Number(mesAtual.quantidade || 0),
          },
          meta: meta ? {
            metaVendas: meta.metaVendas,
            metaQuantidade: meta.metaQuantidade || 0,
          } : null,
          diasPassados,
          diasRestantes,
          projecaoMes: Math.round(projecaoMes),
          ritmoNecessario: meta && diasRestantes > 0 
            ? Math.round((meta.metaVendas - Number(mesAtual.totalVendido || 0)) / diasRestantes)
            : 0,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
