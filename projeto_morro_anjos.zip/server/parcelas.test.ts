import { describe, expect, it } from "vitest";
import { z } from "zod";

describe("parcelas status schema", () => {
  const statusSchema = z.enum(["pendente", "recebida", "atrasada", "cancelada", "inadimplente"]);

  it("aceita status 'recebida' como válido", () => {
    expect(() => statusSchema.parse("recebida")).not.toThrow();
  });

  it("aceita status 'cancelada' como válido", () => {
    expect(() => statusSchema.parse("cancelada")).not.toThrow();
  });

  it("aceita status 'pendente' como válido", () => {
    expect(() => statusSchema.parse("pendente")).not.toThrow();
  });

  it("aceita status 'atrasada' como válido", () => {
    expect(() => statusSchema.parse("atrasada")).not.toThrow();
  });

  it("aceita status 'inadimplente' como válido", () => {
    expect(() => statusSchema.parse("inadimplente")).not.toThrow();
  });

  it("rejeita status inválido", () => {
    expect(() => statusSchema.parse("invalido")).toThrow();
  });
});
