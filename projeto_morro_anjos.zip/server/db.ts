import { eq, desc, and, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, vendas, parcelas, metas, InsertVenda, InsertParcela, InsertMeta } from "../drizzle/schema";
import bcrypt from "bcryptjs";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ AUTENTICAÇÃO ============

export async function createUser(username: string, password: string, name: string, email?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const passwordHash = await bcrypt.hash(password, 10);

  const result = await db.insert(users).values({
    username,
    passwordHash,
    name,
    email: email || null,
    role: "user",
  });

  return result;
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function verifyPassword(password: string, passwordHash: string): Promise<boolean> {
  return await bcrypt.compare(password, passwordHash);
}

export async function updateLastSignIn(userId: number) {
  const db = await getDb();
  if (!db) return;

  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, userId));
}

// ============ VENDAS ============

export async function createVenda(venda: InsertVenda) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(vendas).values(venda);
  return result;
}

export async function getVendaById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(vendas).where(eq(vendas.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVendaByCodigo(codigo: string, usuarioId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(vendas)
    .where(and(eq(vendas.codigo, codigo), eq(vendas.usuarioId, usuarioId)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVendasByUsuario(usuarioId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(vendas)
    .where(eq(vendas.usuarioId, usuarioId))
    .orderBy(desc(vendas.dataVenda));
}

export async function getAllVendas() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(vendas).orderBy(desc(vendas.dataVenda));
}

export async function updateVenda(id: number, data: Partial<InsertVenda>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(vendas).set(data).where(eq(vendas.id, id));
}

export async function deleteVenda(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Primeiro exclui todas as parcelas relacionadas
  await db.delete(parcelas).where(eq(parcelas.vendaId, id));
  
  // Depois exclui a venda
  await db.delete(vendas).where(eq(vendas.id, id));
}

// ============ PARCELAS ============

export async function createParcela(parcela: InsertParcela) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(parcelas).values(parcela);
  return result;
}

export async function getParcelasByVenda(vendaId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(parcelas)
    .where(eq(parcelas.vendaId, vendaId))
    .orderBy(parcelas.numeroParcela);
}

export async function updateParcela(id: number, data: Partial<InsertParcela>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(parcelas).set(data).where(eq(parcelas.id, id));
}

export async function marcarParcelaRecebida(id: number, dataRecebimento: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(parcelas).set({
    status: "recebida",
    dataRecebimento: dataRecebimento,
  }).where(eq(parcelas.id, id));
}

export async function getParcelasPendentes(usuarioId?: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select({
    id: parcelas.id,
    vendaId: parcelas.vendaId,
    numeroParcela: parcelas.numeroParcela,
    valorParcela: parcelas.valorParcela,
    dataVencimento: parcelas.dataVencimento,
    dataRecebimento: parcelas.dataRecebimento,
    status: parcelas.status,
    observacoes: parcelas.observacoes,
    createdAt: parcelas.createdAt,
    updatedAt: parcelas.updatedAt,
    // Dados da venda
    vendaCodigo: vendas.codigo,
    vendaClienteNome: vendas.clienteNome,
    vendaDataVenda: vendas.dataVenda,
  })
  .from(parcelas)
  .leftJoin(vendas, eq(parcelas.vendaId, vendas.id))
  .where(usuarioId ? and(eq(parcelas.status, "pendente"), eq(vendas.usuarioId, usuarioId)) : eq(parcelas.status, "pendente"))
  .orderBy(parcelas.dataVencimento);

  return result;
}

export async function getParcelasPorPeriodo(dataInicio: Date, dataFim: Date) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(parcelas)
    .where(
      and(
        gte(parcelas.dataVencimento, dataInicio),
        lte(parcelas.dataVencimento, dataFim)
      )
    )
    .orderBy(parcelas.dataVencimento);
}

// ============ ESTATÍSTICAS ============

export async function getEstatisticasGerais(usuarioId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select({
    totalVendas: sql<number>`COUNT(*)`,
    valorTotalVendido: sql<number>`SUM(${vendas.valorTotal})`,
    valorTotalComissoes: sql<number>`SUM(${vendas.valorComissaoTotal})`,
  }).from(vendas).where(and(eq(vendas.status, "ativa"), eq(vendas.usuarioId, usuarioId)));

  return result[0] || null;
}

export async function getEstatisticasParcelas(usuarioId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select({
    totalParcelas: sql<number>`COUNT(*)`,
    parcelasPendentes: sql<number>`SUM(CASE WHEN ${parcelas.status} = 'pendente' THEN 1 ELSE 0 END)`,
    parcelasRecebidas: sql<number>`SUM(CASE WHEN ${parcelas.status} = 'recebida' THEN 1 ELSE 0 END)`,
    parcelasAtrasadas: sql<number>`SUM(CASE WHEN ${parcelas.status} = 'atrasada' THEN 1 ELSE 0 END)`,
    valorPendente: sql<number>`SUM(CASE WHEN ${parcelas.status} = 'pendente' THEN ${parcelas.valorParcela} ELSE 0 END)`,
    valorRecebido: sql<number>`SUM(CASE WHEN ${parcelas.status} = 'recebida' THEN ${parcelas.valorParcela} ELSE 0 END)`,
  }).from(parcelas)
  .leftJoin(vendas, eq(parcelas.vendaId, vendas.id))
  .where(eq(vendas.usuarioId, usuarioId));

  return result[0] || null;
}


// ============ METAS ============

export async function getMeta(usuarioId: number, mes: number, ano: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(metas)
    .where(and(
      eq(metas.usuarioId, usuarioId),
      eq(metas.mes, mes),
      eq(metas.ano, ano)
    ))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMetasByUsuario(usuarioId: number, ano?: number) {
  const db = await getDb();
  if (!db) return [];

  if (ano) {
    return await db.select().from(metas)
      .where(and(eq(metas.usuarioId, usuarioId), eq(metas.ano, ano)))
      .orderBy(metas.mes);
  }

  return await db.select().from(metas)
    .where(eq(metas.usuarioId, usuarioId))
    .orderBy(desc(metas.ano), metas.mes);
}

export async function createOrUpdateMeta(usuarioId: number, mes: number, ano: number, metaVendas: number, metaQuantidade?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existingMeta = await getMeta(usuarioId, mes, ano);

  if (existingMeta) {
    await db.update(metas).set({
      metaVendas,
      metaQuantidade: metaQuantidade ?? 0,
    }).where(eq(metas.id, existingMeta.id));
    return { ...existingMeta, metaVendas, metaQuantidade };
  } else {
    const result = await db.insert(metas).values({
      usuarioId,
      mes,
      ano,
      metaVendas,
      metaQuantidade: metaQuantidade ?? 0,
    });
    return result;
  }
}

export async function deleteMeta(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(metas).where(eq(metas.id, id));
}

export async function getVendasPorMes(usuarioId: number, mes: number, ano: number) {
  const db = await getDb();
  if (!db) return { totalVendido: 0, quantidade: 0 };

  // Usar UTC para evitar problemas de timezone
  // O dia 01 em UTC-3 pode virar dia 31 do mês anterior em UTC
  const dataInicio = new Date(Date.UTC(ano, mes - 1, 1, 0, 0, 0));
  const dataFim = new Date(Date.UTC(ano, mes, 0, 23, 59, 59));

  const result = await db.select({
    totalVendido: sql<number>`COALESCE(SUM(${vendas.valorTotal}), 0)`,
    quantidade: sql<number>`COUNT(*)`,
  }).from(vendas)
    .where(and(
      eq(vendas.usuarioId, usuarioId),
      eq(vendas.status, "ativa"),
      gte(vendas.dataVenda, dataInicio),
      lte(vendas.dataVenda, dataFim)
    ));

  return result[0] || { totalVendido: 0, quantidade: 0 };
}
