import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock do banco de dados
vi.mock("./db", () => ({
  getMeta: vi.fn(),
  getMetasByUsuario: vi.fn(),
  createOrUpdateMeta: vi.fn(),
  deleteMeta: vi.fn(),
  getVendasPorMes: vi.fn(),
}));

import * as db from "./db";

describe("Metas - Funções de banco de dados", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("getMeta", () => {
    it("deve retornar meta existente para usuário/mês/ano", async () => {
      const mockMeta = {
        id: 1,
        usuarioId: 1,
        mes: 12,
        ano: 2024,
        metaVendas: 10000000, // R$ 100.000,00 em centavos
        metaQuantidade: 5,
      };

      vi.mocked(db.getMeta).mockResolvedValue(mockMeta);

      const result = await db.getMeta(1, 12, 2024);

      expect(result).toEqual(mockMeta);
      expect(db.getMeta).toHaveBeenCalledWith(1, 12, 2024);
    });

    it("deve retornar undefined quando não há meta", async () => {
      vi.mocked(db.getMeta).mockResolvedValue(undefined);

      const result = await db.getMeta(1, 1, 2025);

      expect(result).toBeUndefined();
    });
  });

  describe("getMetasByUsuario", () => {
    it("deve retornar lista de metas do usuário", async () => {
      const mockMetas = [
        { id: 1, usuarioId: 1, mes: 11, ano: 2024, metaVendas: 8000000, metaQuantidade: 4 },
        { id: 2, usuarioId: 1, mes: 12, ano: 2024, metaVendas: 10000000, metaQuantidade: 5 },
      ];

      vi.mocked(db.getMetasByUsuario).mockResolvedValue(mockMetas);

      const result = await db.getMetasByUsuario(1, 2024);

      expect(result).toHaveLength(2);
      expect(result[0].mes).toBe(11);
      expect(result[1].mes).toBe(12);
    });

    it("deve retornar array vazio quando não há metas", async () => {
      vi.mocked(db.getMetasByUsuario).mockResolvedValue([]);

      const result = await db.getMetasByUsuario(999);

      expect(result).toEqual([]);
    });
  });

  describe("createOrUpdateMeta", () => {
    it("deve criar nova meta quando não existe", async () => {
      vi.mocked(db.createOrUpdateMeta).mockResolvedValue({ insertId: 1 } as any);

      const result = await db.createOrUpdateMeta(1, 1, 2025, 15000000, 6);

      expect(db.createOrUpdateMeta).toHaveBeenCalledWith(1, 1, 2025, 15000000, 6);
    });

    it("deve atualizar meta existente", async () => {
      const mockUpdatedMeta = {
        id: 1,
        usuarioId: 1,
        mes: 12,
        ano: 2024,
        metaVendas: 12000000,
        metaQuantidade: 6,
      };

      vi.mocked(db.createOrUpdateMeta).mockResolvedValue(mockUpdatedMeta);

      const result = await db.createOrUpdateMeta(1, 12, 2024, 12000000, 6);

      expect(result).toEqual(mockUpdatedMeta);
    });
  });

  describe("getVendasPorMes", () => {
    it("deve retornar total vendido e quantidade para o mês", async () => {
      const mockVendas = {
        totalVendido: 8500000,
        quantidade: 4,
      };

      vi.mocked(db.getVendasPorMes).mockResolvedValue(mockVendas);

      const result = await db.getVendasPorMes(1, 12, 2024);

      expect(result.totalVendido).toBe(8500000);
      expect(result.quantidade).toBe(4);
    });

    it("deve retornar zeros quando não há vendas no mês", async () => {
      vi.mocked(db.getVendasPorMes).mockResolvedValue({ totalVendido: 0, quantidade: 0 });

      const result = await db.getVendasPorMes(1, 1, 2025);

      expect(result.totalVendido).toBe(0);
      expect(result.quantidade).toBe(0);
    });
  });
});

describe("Metas - Cálculos de projeção", () => {
  it("deve calcular média corretamente de 3 meses", () => {
    const meses = [
      { totalVendido: 10000000, quantidade: 5 },
      { totalVendido: 8000000, quantidade: 4 },
      { totalVendido: 12000000, quantidade: 6 },
    ];

    const mediaVendido = meses.reduce((sum, m) => sum + m.totalVendido, 0) / 3;
    const mediaQuantidade = meses.reduce((sum, m) => sum + m.quantidade, 0) / 3;

    expect(mediaVendido).toBe(10000000);
    expect(mediaQuantidade).toBe(5);
  });

  it("deve calcular ritmo necessário para atingir meta", () => {
    const meta = 10000000; // R$ 100.000
    const vendidoAtual = 6000000; // R$ 60.000
    const diasRestantes = 10;

    const ritmoNecessario = Math.round((meta - vendidoAtual) / diasRestantes);

    expect(ritmoNecessario).toBe(400000); // R$ 4.000/dia
  });

  it("deve calcular projeção do mês baseada no ritmo atual", () => {
    const vendidoAtual = 6000000; // R$ 60.000
    const diasPassados = 15;
    const diasNoMes = 30;

    const ritmoAtual = vendidoAtual / diasPassados;
    const projecaoMes = Math.round(ritmoAtual * diasNoMes);

    expect(projecaoMes).toBe(12000000); // R$ 120.000
  });

  it("deve retornar progresso 100% quando meta é atingida", () => {
    const meta = 10000000;
    const vendido = 12000000;

    const progresso = Math.min((vendido / meta) * 100, 100);

    expect(progresso).toBe(100);
  });
});

describe("Metas - Validações de data", () => {
  it("deve validar mês entre 1 e 12", () => {
    const validarMes = (mes: number) => mes >= 1 && mes <= 12;

    expect(validarMes(1)).toBe(true);
    expect(validarMes(12)).toBe(true);
    expect(validarMes(0)).toBe(false);
    expect(validarMes(13)).toBe(false);
  });

  it("deve validar ano razoável", () => {
    const validarAno = (ano: number) => ano >= 2020 && ano <= 2100;

    expect(validarAno(2024)).toBe(true);
    expect(validarAno(2025)).toBe(true);
    expect(validarAno(2019)).toBe(false);
    expect(validarAno(2101)).toBe(false);
  });

  it("deve calcular corretamente dias restantes no mês", () => {
    // Dezembro 2024 tem 31 dias
    const ultimoDiaDezembro = new Date(2024, 12, 0).getDate();
    expect(ultimoDiaDezembro).toBe(31);

    // Fevereiro 2024 (ano bissexto) tem 29 dias
    const ultimoDiaFevereiro2024 = new Date(2024, 2, 0).getDate();
    expect(ultimoDiaFevereiro2024).toBe(29);

    // Fevereiro 2025 (não bissexto) tem 28 dias
    const ultimoDiaFevereiro2025 = new Date(2025, 2, 0).getDate();
    expect(ultimoDiaFevereiro2025).toBe(28);
  });
});
