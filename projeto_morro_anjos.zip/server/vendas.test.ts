import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("vendas.simular", () => {
  it("calcula corretamente a comissão de 2% e parcelas", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const resultado = await caller.vendas.simular({
      valorTotal: 10000000, // R$ 100.000,00 em centavos
      percentualEntrada: 17,
      parcelasEntrada: 5,
      taxaComissao: 200, // 2%
    });

    // Verifica se a comissão total é 2% do valor
    expect(resultado.valorComissaoTotal).toBe(200000); // R$ 2.000,00 em centavos

    // Verifica se o número de parcelas está correto
    expect(resultado.parcelas.length).toBe(5);
    expect(resultado.parcelasEntrada).toBe(5);

    // Verifica se a soma das parcelas é igual à comissão total
    const somaParcelas = resultado.parcelas.reduce((sum, p) => sum + p.valorParcela, 0);
    expect(somaParcelas).toBe(resultado.valorComissaoTotal);

    // Verifica se cada parcela tem número sequencial
    resultado.parcelas.forEach((parcela, index) => {
      expect(parcela.numeroParcela).toBe(index + 1);
    });
  });

  it("calcula parcelas com vencimentos mensais corretos", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const dataBase = new Date("2024-01-15");

    const resultado = await caller.vendas.simular({
      valorTotal: 5000000, // R$ 50.000,00
      percentualEntrada: 20,
      parcelasEntrada: 3,
      dataVenda: dataBase,
    });

    // Verifica se as datas de vencimento são mensais
    expect(resultado.parcelas.length).toBe(3);

    const primeiraData = new Date(resultado.parcelas[0].dataVencimento);
    expect(primeiraData.getMonth()).toBe((dataBase.getMonth() + 1) % 12);

    const segundaData = new Date(resultado.parcelas[1].dataVencimento);
    expect(segundaData.getMonth()).toBe((dataBase.getMonth() + 2) % 12);
  });

  it("distribui corretamente o arredondamento na última parcela", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const resultado = await caller.vendas.simular({
      valorTotal: 10000000, // R$ 100.000,00
      percentualEntrada: 17,
      parcelasEntrada: 3, // Vai gerar valores que não dividem exatamente
      taxaComissao: 200,
    });

    // Comissão total: R$ 2.000,00 (200000 centavos)
    // Dividido por 3: 66666.67 por parcela
    // Deve arredondar e ajustar a última parcela

    const somaParcelas = resultado.parcelas.reduce((sum, p) => sum + p.valorParcela, 0);
    expect(somaParcelas).toBe(200000);
  });

  it("funciona com 1 parcela (pagamento à vista)", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const resultado = await caller.vendas.simular({
      valorTotal: 10000000,
      percentualEntrada: 100,
      parcelasEntrada: 1,
    });

    expect(resultado.parcelas.length).toBe(1);
    expect(resultado.parcelas[0].valorParcela).toBe(200000);
    expect(resultado.parcelas[0].numeroParcela).toBe(1);
  });

  it("funciona com 10 parcelas (máximo permitido)", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const resultado = await caller.vendas.simular({
      valorTotal: 10000000,
      percentualEntrada: 10,
      parcelasEntrada: 10,
    });

    expect(resultado.parcelas.length).toBe(10);

    const somaParcelas = resultado.parcelas.reduce((sum, p) => sum + p.valorParcela, 0);
    expect(somaParcelas).toBe(200000);
  });
});

describe("vendas router validation", () => {
  it("aceita valores válidos de entrada", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Teste com valores válidos
    const resultado = await caller.vendas.simular({
      valorTotal: 5000000,
      percentualEntrada: 50,
      parcelasEntrada: 5,
    });

    expect(resultado).toBeDefined();
    expect(resultado.valorComissaoTotal).toBeGreaterThan(0);
  });
});
