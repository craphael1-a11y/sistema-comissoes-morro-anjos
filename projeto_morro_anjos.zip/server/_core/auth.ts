import jwt from "jsonwebtoken";
import { ENV } from "./env";
import * as db from "../db";

const JWT_SECRET = ENV.jwtSecret;
const TOKEN_EXPIRY = "7d";

export interface JWTPayload {
  userId: number;
  username: string;
}

export function generateToken(userId: number, username: string): string {
  return jwt.sign({ userId, username } as JWTPayload, JWT_SECRET, {
    expiresIn: TOKEN_EXPIRY,
  });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;
    return decoded;
  } catch {
    return null;
  }
}

export async function authenticateUser(username: string, password: string) {
  const user = await db.getUserByUsername(username);
  
  if (!user) {
    return null;
  }

  const isValid = await db.verifyPassword(password, user.passwordHash);
  
  if (!isValid) {
    return null;
  }

  await db.updateLastSignIn(user.id);

  return {
    id: user.id,
    username: user.username,
    name: user.name,
    email: user.email,
    role: user.role,
  };
}

export async function registerUser(username: string, password: string, name: string, email?: string) {
  // Verifica se o username já existe
  const existing = await db.getUserByUsername(username);
  
  if (existing) {
    throw new Error("Nome de usuário já existe");
  }

  // Valida senha mínima
  if (password.length < 6) {
    throw new Error("A senha deve ter no mínimo 6 caracteres");
  }

  // Cria o usuário
  await db.createUser(username, password, name, email);

  // Busca o usuário criado
  const user = await db.getUserByUsername(username);
  
  if (!user) {
    throw new Error("Erro ao criar usuário");
  }

  return {
    id: user.id,
    username: user.username,
    name: user.name,
    email: user.email,
    role: user.role,
  };
}
