import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(user?: AuthenticatedUser): TrpcContext {
  const mockRes = {
    cookie: () => {},
    clearCookie: () => {},
  };

  const ctx: TrpcContext = {
    user: user || null,
    req: {
      protocol: "https",
      headers: {},
      cookies: {},
    } as TrpcContext["req"],
    res: mockRes as TrpcContext["res"],
  };

  return ctx;
}

describe("auth.register", () => {
  it("cria um novo usuário com sucesso", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueUsername = `testuser_${Date.now()}`;

    const result = await caller.auth.register({
      username: uniqueUsername,
      password: "senha123",
      name: "Usuário Teste",
      email: "teste@example.com",
    });

    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user.username).toBe(uniqueUsername);
    expect(result.user.name).toBe("Usuário Teste");
  });

  it("rejeita registro com username duplicado", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueUsername = `duplicate_${Date.now()}`;

    // Primeiro registro
    await caller.auth.register({
      username: uniqueUsername,
      password: "senha123",
      name: "Primeiro Usuário",
    });

    // Segundo registro com mesmo username deve falhar
    await expect(
      caller.auth.register({
        username: uniqueUsername,
        password: "outrasenha",
        name: "Segundo Usuário",
      })
    ).rejects.toThrow("Nome de usuário já existe");
  });

  it("rejeita senha com menos de 6 caracteres", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Zod validação retorna erro diferente
    await expect(
      caller.auth.register({
        username: `user_${Date.now()}`,
        password: "12345", // Apenas 5 caracteres
        name: "Usuário Teste",
      })
    ).rejects.toThrow(); // Apenas verifica se lança erro
  });

  it("permite registro sem email (campo opcional)", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueUsername = `noemail_${Date.now()}`;

    const result = await caller.auth.register({
      username: uniqueUsername,
      password: "senha123",
      name: "Usuário Sem Email",
    });

    expect(result.success).toBe(true);
    expect(result.user.username).toBe(uniqueUsername);
  });
});

describe("auth.login", () => {
  it("faz login com credenciais válidas", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueUsername = `logintest_${Date.now()}`;

    // Primeiro cria o usuário
    await caller.auth.register({
      username: uniqueUsername,
      password: "senha123",
      name: "Usuário Login Test",
    });

    // Depois faz login
    const result = await caller.auth.login({
      username: uniqueUsername,
      password: "senha123",
    });

    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user.username).toBe(uniqueUsername);
  });

  it("rejeita login com senha incorreta", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueUsername = `wrongpass_${Date.now()}`;

    // Cria o usuário
    await caller.auth.register({
      username: uniqueUsername,
      password: "senhaCorreta",
      name: "Usuário Teste",
    });

    // Tenta login com senha errada
    await expect(
      caller.auth.login({
        username: uniqueUsername,
        password: "senhaErrada",
      })
    ).rejects.toThrow("Usuário ou senha inválidos");
  });

  it("rejeita login com usuário inexistente", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.login({
        username: "usuarioInexistente",
        password: "qualquersenha",
      })
    ).rejects.toThrow("Usuário ou senha inválidos");
  });
});

describe("auth.logout", () => {
  it("faz logout com sucesso", async () => {
    const user: AuthenticatedUser = {
      id: 1,
      username: "testuser",
      passwordHash: "hash",
      name: "Test User",
      email: null,
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
      openId: null,
      loginMethod: null,
    };

    const ctx = createTestContext(user);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();

    expect(result.success).toBe(true);
  });
});

describe("auth.me", () => {
  it("retorna null quando não autenticado", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();

    expect(result).toBeNull();
  });

  it("retorna dados do usuário quando autenticado", async () => {
    const user: AuthenticatedUser = {
      id: 1,
      username: "testuser",
      passwordHash: "hash",
      name: "Test User",
      email: "test@example.com",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
      openId: null,
      loginMethod: null,
    };

    const ctx = createTestContext(user);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();

    expect(result).toBeDefined();
    expect(result?.username).toBe("testuser");
    expect(result?.name).toBe("Test User");
  });
});
