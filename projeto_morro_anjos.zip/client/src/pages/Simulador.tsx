import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString("pt-BR");
}

export default function Simulador() {
  const { user, loading } = useAuth();
  const [formData, setFormData] = useState({
    cargo: "consultor" as "gerente" | "consultor" | "supervisor" | "promotor",
    valorTotal: "100000",
    percentualEntrada: "17",
    parcelasEntrada: "5",
  });

  const [simular, setSimular] = useState(false);

  const { data: simulacao } = trpc.vendas.simular.useQuery(
    {
      cargo: formData.cargo,
      valorTotal: Math.round(parseFloat(formData.valorTotal) * 100),
      percentualEntrada: parseInt(formData.percentualEntrada),
      parcelasEntrada: parseInt(formData.parcelasEntrada),
    },
    { enabled: simular }
  );

  const handleSimular = () => {
    setSimular(true);
  };

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="max-w-4xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Simulador</h1>
          <p className="text-muted-foreground mt-2">
            Simule o parcelamento de comissões antes de cadastrar a venda
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Dados da Simulação</CardTitle>
            <CardDescription>
              Preencha os valores para calcular as parcelas de comissão
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2 mb-4">
                <Label htmlFor="cargo">Cargo do Vendedor</Label>
                <select
                  id="cargo"
                  value={formData.cargo}
                  onChange={(e) => {
                    setFormData({ ...formData, cargo: e.target.value as any });
                    setSimular(false);
                  }}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="gerente">Gerente (1%)</option>
                  <option value="consultor">Consultor (2%)</option>
                  <option value="supervisor">Supervisor (2%)</option>
                  <option value="promotor">Promotor (1,5%)</option>
                </select>
              </div>
              
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="valorTotal">Valor Total (R$)</Label>
                  <Input
                    id="valorTotal"
                    type="number"
                    step="0.01"
                    value={formData.valorTotal}
                    onChange={(e) => {
                      setFormData({ ...formData, valorTotal: e.target.value });
                      setSimular(false);
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="percentualEntrada">% Entrada</Label>
                  <Input
                    id="percentualEntrada"
                    type="number"
                    min="1"
                    max="100"
                    value={formData.percentualEntrada}
                    onChange={(e) => {
                      setFormData({ ...formData, percentualEntrada: e.target.value });
                      setSimular(false);
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="parcelasEntrada">Parcelas (1-10)</Label>
                  <Input
                    id="parcelasEntrada"
                    type="number"
                    min="1"
                    max="10"
                    value={formData.parcelasEntrada}
                    onChange={(e) => {
                      setFormData({ ...formData, parcelasEntrada: e.target.value });
                      setSimular(false);
                    }}
                  />
                </div>
              </div>

              <Button onClick={handleSimular}>Simular Parcelamento</Button>
            </div>
          </CardContent>
        </Card>

        {simular && simulacao && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Resultado da Simulação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <p className="text-sm text-muted-foreground">Valor da Venda</p>
                    <p className="text-2xl font-bold">
                      {formatCurrency(simulacao.valorTotal)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Comissão Total (2%)</p>
                    <p className="text-2xl font-bold">
                      {formatCurrency(simulacao.valorComissaoTotal)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Número de Parcelas</p>
                    <p className="text-2xl font-bold">{simulacao.parcelasEntrada}x</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cronograma de Parcelas</CardTitle>
                <CardDescription>
                  Previsão de recebimento das parcelas de comissão
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {simulacao.parcelas.map((parcela) => (
                    <div
                      key={parcela.numeroParcela}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary">
                          <span className="font-semibold">{parcela.numeroParcela}</span>
                        </div>
                        <div>
                          <p className="font-semibold">{formatCurrency(parcela.valorParcela)}</p>
                          <p className="text-sm text-muted-foreground">
                            Vencimento: {formatDate(parcela.dataVencimento)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
