import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { DollarSign, TrendingUp, Clock, CheckCircle2 } from "lucide-react";

function formatCurrency(value: number | null | undefined): string {
  if (!value) return "R$ 0,00";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

export default function Dashboard() {
  const { user, loading } = useAuth();
  const { data: stats, isLoading } = trpc.dashboard.estatisticas.useQuery();

  if (loading) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  if (!user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  const vendas = stats?.vendas;
  const parcelas = stats?.parcelas;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Seu desempenho de vendas e comissões
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="h-4 w-24 bg-muted animate-pulse rounded" />
                </CardHeader>
                <CardContent>
                  <div className="h-8 w-32 bg-muted animate-pulse rounded mb-2" />
                  <div className="h-3 w-20 bg-muted animate-pulse rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Vendido</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(vendas?.valorTotalVendido)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {vendas?.totalVendas || 0} vendas ativas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Comissões Totais</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(vendas?.valorTotalComissoes)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    2% sobre vendas ativas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Parcelas Pendentes</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(parcelas?.valorPendente)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {parcelas?.parcelasPendentes || 0} parcelas a receber
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Já Recebido</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(parcelas?.valorRecebido)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {parcelas?.parcelasRecebidas || 0} parcelas recebidas
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Resumo de Parcelas</CardTitle>
                  <CardDescription>Status das parcelas de comissão</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-yellow-500" />
                      <span className="text-sm">Pendentes</span>
                    </div>
                    <span className="font-semibold">{parcelas?.parcelasPendentes || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-green-500" />
                      <span className="text-sm">Recebidas</span>
                    </div>
                    <span className="font-semibold">{parcelas?.parcelasRecebidas || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-red-500" />
                      <span className="text-sm">Atrasadas</span>
                    </div>
                    <span className="font-semibold">{parcelas?.parcelasAtrasadas || 0}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Informações do Sistema</CardTitle>
                  <CardDescription>Controle de comissões de timeshare</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      <strong>Taxa de Comissão:</strong> 2% sobre o valor vendido
                    </p>
                    <p className="text-sm text-muted-foreground">
                      <strong>Parcelamento:</strong> Vinculado à entrada do cliente (1 a 10x)
                    </p>
                    <p className="text-sm text-muted-foreground">
                      <strong>Total de Parcelas:</strong> {parcelas?.totalParcelas || 0}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
