import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Calendar, TrendingUp, ChevronDown } from "lucide-react";
import { useState } from "react";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatMonthYear(date: Date): string {
  return new Date(date).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
}

interface ParcelasPorMes {
  mes: string;
  ano: number;
  totalPendente: number;
  totalRecebido: number;
  totalInadimplente: number;
  quantidadePendente: number;
  quantidadeRecebida: number;
  quantidadeInadimplente: number;
}

export default function Carteira() {
  const { user, loading } = useAuth();
  const { data: parcelas, isLoading } = trpc.parcelas.listPendentes.useQuery();
  const [expandedMeses, setExpandedMeses] = useState<Record<string, boolean>>({});

  const toggleMes = (chave: string) => {
    setExpandedMeses((prev) => ({
      ...prev,
      [chave]: !prev[chave],
    }));
  };

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  // Agrupar parcelas por mês/ano
  const parcelasPorMes: Record<string, ParcelasPorMes> = {};
  
  if (parcelas) {
    parcelas.forEach((parcela) => {
      const data = new Date(parcela.dataVencimento);
      const mes = data.toLocaleDateString("pt-BR", { month: "long" });
      const ano = data.getFullYear();
      const chave = `${ano}-${String(data.getMonth() + 1).padStart(2, "0")}`;

      if (!parcelasPorMes[chave]) {
        parcelasPorMes[chave] = {
          mes,
          ano,
          totalPendente: 0,
          totalRecebido: 0,
          totalInadimplente: 0,
          quantidadePendente: 0,
          quantidadeRecebida: 0,
          quantidadeInadimplente: 0,
        };
      }

      if (parcela.status === "pendente" || parcela.status === "atrasada") {
        parcelasPorMes[chave].totalPendente += parcela.valorParcela;
        parcelasPorMes[chave].quantidadePendente++;
      } else if (parcela.status === "recebida") {
        parcelasPorMes[chave].totalRecebido += parcela.valorParcela;
        parcelasPorMes[chave].quantidadeRecebida++;
      } else if (parcela.status === "inadimplente") {
        parcelasPorMes[chave].totalInadimplente += parcela.valorParcela;
        parcelasPorMes[chave].quantidadeInadimplente++;
      }
    });
  }

  // Ordenar por data (mais recente primeiro)
  const mesesOrdenados = Object.entries(parcelasPorMes).sort(([a], [b]) => a.localeCompare(b));

  // Calcular totais gerais
  const totais = mesesOrdenados.reduce(
    (acc, [, dados]) => ({
      pendente: acc.pendente + dados.totalPendente,
      recebido: acc.recebido + dados.totalRecebido,
      inadimplente: acc.inadimplente + dados.totalInadimplente,
    }),
    { pendente: 0, recebido: 0, inadimplente: 0 }
  );

  return (
    <DashboardLayout>
      <div className="space-y-6 px-2 sm:px-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Carteira de Recebimentos</h1>
          <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base">
            Controle mensal de comissões a receber
          </p>
        </div>

        <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total a Receber</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totais.pendente)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Parcelas pendentes e atrasadas
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Já Recebido</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(totais.recebido)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Parcelas recebidas
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inadimplente</CardTitle>
              <TrendingUp className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{formatCurrency(totais.inadimplente)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Parcelas inadimplentes
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Lista Mensal */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="h-6 w-48 bg-muted animate-pulse rounded" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : mesesOrdenados.length > 0 ? (
          <div className="space-y-4">
            {mesesOrdenados.map(([chave, dados]) => {
              const isExpanded = expandedMeses[chave];
              const totalParcelas = dados.quantidadePendente + dados.quantidadeRecebida + dados.quantidadeInadimplente;
              const totalValor = dados.totalPendente + dados.totalRecebido + dados.totalInadimplente;
              
              return (
                <Card key={chave} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader 
                    onClick={() => toggleMes(chave)} 
                    className="pb-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 flex-1">
                        <Calendar className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <CardTitle className="text-lg capitalize">
                            {dados.mes} {dados.ano}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {totalParcelas} parcelas • {formatCurrency(totalValor)}
                          </CardDescription>
                        </div>
                      </div>
                      <ChevronDown
                        className={`h-5 w-5 text-muted-foreground transition-transform ${
                          isExpanded ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                  </CardHeader>
                  
                  {isExpanded && (
                    <CardContent className="pt-0">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 pb-6 border-b">
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-muted-foreground">A Receber</p>
                            <Badge variant="secondary">{dados.quantidadePendente}</Badge>
                          </div>
                          <p className="text-xl font-bold">{formatCurrency(dados.totalPendente)}</p>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-muted-foreground">Recebido</p>
                            <Badge variant="default">{dados.quantidadeRecebida}</Badge>
                          </div>
                          <p className="text-xl font-bold text-green-600">{formatCurrency(dados.totalRecebido)}</p>
                        </div>

                        {dados.totalInadimplente > 0 && (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <p className="text-sm text-muted-foreground">Inadimplente</p>
                              <Badge variant="destructive">{dados.quantidadeInadimplente}</Badge>
                            </div>
                            <p className="text-xl font-bold text-red-600">{formatCurrency(dados.totalInadimplente)}</p>
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold mb-3">Parcelas do mês</h4>
                        {parcelas
                          ?.filter((p) => {
                            const data = new Date(p.dataVencimento);
                            const chaveP = `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, "0")}`;
                            return chaveP === chave;
                          })
                          .map((parcela) => (
                            <div key={parcela.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg text-sm">
                              <div className="flex-1">
                                <p className="font-medium">{parcela.vendaCodigo}</p>
                                {parcela.vendaClienteNome && (
                                  <p className="text-xs text-muted-foreground">
                                    {parcela.vendaClienteNome}
                                  </p>
                                )}
                                <p className="text-xs text-muted-foreground">
                                  Parcela {parcela.numeroParcela}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold">{formatCurrency(parcela.valorParcela)}</p>
                                <Badge
                                  variant={
                                    parcela.status === "recebida"
                                      ? "default"
                                      : parcela.status === "inadimplente"
                                      ? "destructive"
                                      : "secondary"
                                  }
                                  className="text-xs mt-1"
                                >
                                  {parcela.status === "recebida"
                                    ? "Recebida"
                                    : parcela.status === "inadimplente"
                                    ? "Inadimplente"
                                    : "Pendente"}
                                </Badge>
                              </div>
                            </div>
                          ))}
                      </div>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhuma parcela cadastrada</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
