import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { trpc } from "@/lib/trpc";
import { MoreVertical, Check, X, Clock, AlertCircle } from "lucide-react";
import { toast } from "sonner";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString("pt-BR");
}

export default function Comissoes() {
  const { user, loading } = useAuth();
  const { data: parcelas, isLoading, refetch } = trpc.parcelas.listPendentes.useQuery();
  const updateParcelaMutation = trpc.parcelas.update.useMutation({
    onSuccess: () => {
      toast.success("Status da parcela atualizado com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error("Erro ao atualizar parcela: " + error.message);
    },
  });

  const handleUpdateStatus = (id: number, status: "pendente" | "recebida" | "atrasada" | "cancelada" | "inadimplente") => {
    updateParcelaMutation.mutate({ id, status });
  };

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Comissões</h1>
          <p className="text-muted-foreground mt-2">
            Acompanhe todas as parcelas de comissão pendentes
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="h-6 w-48 bg-muted animate-pulse rounded" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : parcelas && parcelas.length > 0 ? (
          <div className="space-y-4">
            {parcelas.map((parcela) => (
              <Card key={parcela.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">
                        Parcela {parcela.numeroParcela} - {parcela.vendaCodigo || `Venda #${parcela.vendaId}`}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {parcela.vendaClienteNome && `Cliente: ${parcela.vendaClienteNome}`}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={
                        parcela.status === "atrasada" ? "destructive" : 
                        parcela.status === "inadimplente" ? "destructive" :
                        parcela.status === "recebida" ? "default" :
                        parcela.status === "cancelada" ? "outline" :
                        "secondary"
                      }>
                        {parcela.status}
                      </Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleUpdateStatus(parcela.id, "recebida")}>
                            <Check className="mr-2 h-4 w-4" />
                            Marcar como Recebida
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(parcela.id, "pendente")}>
                            <Clock className="mr-2 h-4 w-4" />
                            Marcar como Pendente
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(parcela.id, "inadimplente")} className="text-destructive">
                            <AlertCircle className="mr-2 h-4 w-4" />
                            Marcar como Inadimplente
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(parcela.id, "cancelada")} className="text-destructive">
                            <X className="mr-2 h-4 w-4" />
                            Cancelar Parcela
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Valor</p>
                      <p className="font-semibold">{formatCurrency(parcela.valorParcela)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Vencimento</p>
                      <p className="font-semibold">{formatDate(parcela.dataVencimento)}</p>
                    </div>
                    {parcela.vendaDataVenda && (
                      <div>
                        <p className="text-sm text-muted-foreground">Data da Venda</p>
                        <p className="font-semibold">{formatDate(parcela.vendaDataVenda)}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground">Nenhuma parcela pendente</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
