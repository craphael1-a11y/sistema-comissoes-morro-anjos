import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { BarChart3, TrendingUp, PieChart, Calendar, ArrowUp, ArrowDown, Target, Edit2, Save, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

// Componente de barra de progresso simples
function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const percentage = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
      <div 
        className={`h-full rounded-full transition-all duration-500 ${color}`}
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
}

const MESES = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

export default function Graficos() {
  const { user, loading } = useAuth();
  
  const utils = trpc.useUtils();
  
  const hoje = new Date();
  const [mesAtual, setMesAtual] = useState(hoje.getMonth() + 1);
  const [anoAtual, setAnoAtual] = useState(hoje.getFullYear());
  const [editandoMeta, setEditandoMeta] = useState(false);
  const [novaMeta, setNovaMeta] = useState("");
  const [novaMetaQtd, setNovaMetaQtd] = useState("");

  const { data: vendas, isLoading: vendLoading } = trpc.vendas.list.useQuery();
  const { data: parcelas, isLoading: parcelLoading } = trpc.parcelas.listPendentes.useQuery();
  const { data: metaData, isLoading: metaLoading } = trpc.metas.get.useQuery({ mes: mesAtual, ano: anoAtual });
  const { data: projecaoData } = trpc.metas.projecao.useQuery({ mes: mesAtual, ano: anoAtual });

  const salvarMeta = trpc.metas.save.useMutation({
    onSuccess: () => {
      toast.success("Meta salva!", { description: "Sua meta foi atualizada com sucesso." });
      utils.metas.get.invalidate();
      utils.metas.projecao.invalidate();
      setEditandoMeta(false);
    },
    onError: () => {
      toast.error("Erro", { description: "Não foi possível salvar a meta." });
    },
  });

  const handleSalvarMeta = () => {
    const valorMeta = Math.round(parseFloat(novaMeta.replace(/\D/g, "")) || 0);
    const qtdMeta = parseInt(novaMetaQtd) || 0;
    
    if (valorMeta <= 0) {
      toast.error("Erro", { description: "Digite um valor válido para a meta." });
      return;
    }

    salvarMeta.mutate({
      mes: mesAtual,
      ano: anoAtual,
      metaVendas: valorMeta,
      metaQuantidade: qtdMeta,
    });
  };

  if (loading || !user) {
    return <DashboardLayout><div className="flex items-center justify-center h-64">Carregando...</div></DashboardLayout>;
  }

  if (vendLoading || parcelLoading || metaLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <div className="h-6 w-48 bg-muted animate-pulse rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-32 bg-muted animate-pulse rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </DashboardLayout>
    );
  }

  // Preparar dados mensais
  const vendasPorMes: Record<string, { mes: string; mesNum: number; ano: number; vendas: number; comissoes: number; quantidade: number }> = {};
  
  if (vendas) {
    vendas.forEach((venda) => {
      const data = new Date(venda.dataVenda);
      const mes = data.toLocaleDateString("pt-BR", { month: "short" });
      const ano = data.getFullYear();
      const mesNum = data.getMonth();
      const chave = `${ano}-${mesNum}`;

      if (!vendasPorMes[chave]) {
        vendasPorMes[chave] = { mes, mesNum, ano, vendas: 0, comissoes: 0, quantidade: 0 };
      }

      vendasPorMes[chave].vendas += venda.valorTotal;
      vendasPorMes[chave].comissoes += venda.valorComissaoTotal;
      vendasPorMes[chave].quantidade += 1;
    });
  }

  const dadosVendas = Object.values(vendasPorMes).sort((a, b) => {
    if (a.ano !== b.ano) return a.ano - b.ano;
    return a.mesNum - b.mesNum;
  });

  // Projeção de recebimentos por mês
  const recebimentosPorMes: Record<string, { mes: string; mesNum: number; ano: number; valor: number; quantidade: number }> = {};
  
  if (parcelas) {
    parcelas.forEach((parcela) => {
      const data = new Date(parcela.dataVencimento);
      const mes = data.toLocaleDateString("pt-BR", { month: "short" });
      const ano = data.getFullYear();
      const mesNum = data.getMonth();
      const chave = `${ano}-${mesNum}`;

      if (!recebimentosPorMes[chave]) {
        recebimentosPorMes[chave] = { mes, mesNum, ano, valor: 0, quantidade: 0 };
      }

      if (parcela.status === "pendente") {
        recebimentosPorMes[chave].valor += parcela.valorParcela;
        recebimentosPorMes[chave].quantidade += 1;
      }
    });
  }

  const dadosProjecao = Object.values(recebimentosPorMes)
    .filter(d => d.valor > 0)
    .sort((a, b) => {
      if (a.ano !== b.ano) return a.ano - b.ano;
      return a.mesNum - b.mesNum;
    })
    .slice(0, 6);

  // Status das parcelas
  const statusCount = { pendente: 0, recebida: 0, atrasada: 0, inadimplente: 0 };
  let valorPendente = 0;
  let valorRecebido = 0;

  if (parcelas) {
    parcelas.forEach((p) => {
      if (p.status === "recebida") {
        statusCount.recebida++;
        valorRecebido += p.valorParcela;
      } else if (p.status === "atrasada") {
        statusCount.atrasada++;
      } else if (p.status === "inadimplente") {
        statusCount.inadimplente++;
      } else {
        statusCount.pendente++;
        valorPendente += p.valorParcela;
      }
    });
  }

  const totalParcelas = statusCount.pendente + statusCount.recebida + statusCount.atrasada + statusCount.inadimplente;

  // Totais
  const totalVendido = vendas?.reduce((sum, v) => sum + v.valorTotal, 0) || 0;
  const totalComissoes = vendas?.reduce((sum, v) => sum + v.valorComissaoTotal, 0) || 0;

  // Calcular tendência
  let tendencia = 0;
  if (dadosVendas.length >= 2) {
    const ultimo = dadosVendas[dadosVendas.length - 1].vendas;
    const anterior = dadosVendas[dadosVendas.length - 2].vendas;
    if (anterior > 0) {
      tendencia = ((ultimo - anterior) / anterior) * 100;
    }
  }

  // Maior valor para escala dos gráficos
  const maxVendaMensal = Math.max(...dadosVendas.map(d => d.vendas), 1);
  const maxProjecao = Math.max(...dadosProjecao.map(d => d.valor), 1);

  // Dados da meta atual
  const metaAtual = metaData?.meta;
  const vendasMesAtual = metaData?.vendas;
  const progressoMeta = metaAtual && vendasMesAtual 
    ? Math.min((Number(vendasMesAtual.totalVendido) / metaAtual.metaVendas) * 100, 100)
    : 0;

  return (
    <DashboardLayout>
      <div className="space-y-6 px-2 sm:px-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <BarChart3 className="h-8 w-8 text-blue-600" />
            Gráficos e Análises
          </h1>
          <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base">
            Visualize seu desempenho, metas e projeções
          </p>
        </div>

        {/* Seletor de Mês/Ano */}
        <div className="flex flex-wrap gap-2 items-center">
          <select 
            value={mesAtual} 
            onChange={(e) => setMesAtual(Number(e.target.value))}
            className="px-3 py-2 border rounded-md bg-background"
          >
            {MESES.map((mes, idx) => (
              <option key={idx} value={idx + 1}>{mes}</option>
            ))}
          </select>
          <select 
            value={anoAtual} 
            onChange={(e) => setAnoAtual(Number(e.target.value))}
            className="px-3 py-2 border rounded-md bg-background"
          >
            {[2024, 2025, 2026].map((ano) => (
              <option key={ano} value={ano}>{ano}</option>
            ))}
          </select>
        </div>

        {/* Card de Meta Mensal */}
        <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-indigo-800">
                <Target className="h-5 w-5" />
                Meta de {MESES[mesAtual - 1]} {anoAtual}
              </CardTitle>
              <Dialog open={editandoMeta} onOpenChange={setEditandoMeta}>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setNovaMeta(metaAtual ? (metaAtual.metaVendas / 100).toString() : "");
                      setNovaMetaQtd(metaAtual?.metaQuantidade?.toString() || "");
                    }}
                  >
                    <Edit2 className="h-4 w-4 mr-1" />
                    {metaAtual ? "Editar" : "Definir Meta"}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Definir Meta de {MESES[mesAtual - 1]} {anoAtual}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <label className="text-sm font-medium">Meta de Vendas (R$)</label>
                      <Input
                        type="text"
                        placeholder="Ex: 100000"
                        value={novaMeta}
                        onChange={(e) => setNovaMeta(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Digite o valor em reais (sem centavos)
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Meta de Quantidade (opcional)</label>
                      <Input
                        type="number"
                        placeholder="Ex: 5"
                        value={novaMetaQtd}
                        onChange={(e) => setNovaMetaQtd(e.target.value)}
                      />
                    </div>
                    <Button 
                      onClick={handleSalvarMeta} 
                      className="w-full"
                      disabled={salvarMeta.isPending}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {salvarMeta.isPending ? "Salvando..." : "Salvar Meta"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {metaAtual ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-indigo-600">Meta</p>
                    <p className="text-2xl font-bold text-indigo-800">{formatCurrency(metaAtual.metaVendas)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-indigo-600">Realizado</p>
                    <p className="text-2xl font-bold text-indigo-800">{formatCurrency(Number(vendasMesAtual?.totalVendido || 0))}</p>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progresso</span>
                    <span className="font-bold">{progressoMeta.toFixed(1)}%</span>
                  </div>
                  <ProgressBar 
                    value={Number(vendasMesAtual?.totalVendido || 0)} 
                    max={metaAtual.metaVendas} 
                    color={progressoMeta >= 100 ? "bg-green-500" : progressoMeta >= 70 ? "bg-yellow-500" : "bg-indigo-500"} 
                  />
                </div>
                <div className="text-sm text-indigo-700">
                  {progressoMeta >= 100 ? (
                    <span className="text-green-600 font-semibold">🎉 Meta atingida! Parabéns!</span>
                  ) : (
                    <span>Faltam {formatCurrency(metaAtual.metaVendas - Number(vendasMesAtual?.totalVendido || 0))} para atingir a meta</span>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <Target className="h-12 w-12 text-indigo-300 mx-auto mb-2" />
                <p className="text-indigo-600">Nenhuma meta definida para este mês</p>
                <p className="text-sm text-indigo-500">Clique em "Definir Meta" para começar</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Card de Projeção */}
        {projecaoData && (
          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-amber-800">
                <Zap className="h-5 w-5" />
                Projeção e Análise
              </CardTitle>
              <CardDescription className="text-amber-700">
                Baseado no seu desempenho atual e histórico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-3 bg-white/50 rounded-lg">
                  <p className="text-xs text-amber-600">Média 3 meses</p>
                  <p className="text-lg font-bold text-amber-800">{formatCurrency(projecaoData.mediaVendido)}</p>
                </div>
                <div className="p-3 bg-white/50 rounded-lg">
                  <p className="text-xs text-amber-600">Projeção do mês</p>
                  <p className="text-lg font-bold text-amber-800">{formatCurrency(projecaoData.projecaoMes)}</p>
                </div>
                <div className="p-3 bg-white/50 rounded-lg">
                  <p className="text-xs text-amber-600">Dias restantes</p>
                  <p className="text-lg font-bold text-amber-800">{projecaoData.diasRestantes} dias</p>
                </div>
                {projecaoData.meta && projecaoData.ritmoNecessario > 0 && (
                  <div className="p-3 bg-white/50 rounded-lg">
                    <p className="text-xs text-amber-600">Ritmo necessário/dia</p>
                    <p className="text-lg font-bold text-amber-800">{formatCurrency(projecaoData.ritmoNecessario)}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Cards de Resumo Rápido */}
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-600 font-medium">Total Vendido</p>
                  <p className="text-xl sm:text-2xl font-bold text-blue-800">{formatCurrency(totalVendido)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-600 font-medium">Comissões</p>
                  <p className="text-xl sm:text-2xl font-bold text-green-800">{formatCurrency(totalComissoes)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-600 font-medium">A Receber</p>
                  <p className="text-xl sm:text-2xl font-bold text-purple-800">{formatCurrency(valorPendente)}</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className={`bg-gradient-to-br ${tendencia >= 0 ? 'from-emerald-50 to-emerald-100 border-emerald-200' : 'from-red-50 to-red-100 border-red-200'}`}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${tendencia >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>Tendência</p>
                  <p className={`text-xl sm:text-2xl font-bold ${tendencia >= 0 ? 'text-emerald-800' : 'text-red-800'}`}>
                    {tendencia >= 0 ? '+' : ''}{tendencia.toFixed(1)}%
                  </p>
                </div>
                {tendencia >= 0 ? (
                  <ArrowUp className="h-8 w-8 text-emerald-500 opacity-50" />
                ) : (
                  <ArrowDown className="h-8 w-8 text-red-500 opacity-50" />
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico de Evolução Mensal */}
        {dadosVendas.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Evolução Mensal de Vendas
              </CardTitle>
              <CardDescription>Valor total vendido por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dadosVendas.slice(-6).map((item, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium w-20">{item.mes}/{item.ano.toString().slice(-2)}</span>
                      <span className="text-sm text-muted-foreground">{item.quantidade} vendas</span>
                      <span className="text-sm font-bold text-blue-600 w-32 text-right">{formatCurrency(item.vendas)}</span>
                    </div>
                    <ProgressBar value={item.vendas} max={maxVendaMensal} color="bg-blue-500" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Gráfico de Projeção de Recebimentos */}
        {dadosProjecao.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                Projeção de Recebimentos
              </CardTitle>
              <CardDescription>Parcelas pendentes a receber nos próximos meses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dadosProjecao.map((item, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium w-20">{item.mes}/{item.ano.toString().slice(-2)}</span>
                      <span className="text-sm text-muted-foreground">{item.quantidade} parcelas</span>
                      <span className="text-sm font-bold text-green-600 w-32 text-right">{formatCurrency(item.valor)}</span>
                    </div>
                    <ProgressBar value={item.valor} max={maxProjecao} color="bg-green-500" />
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Total Projetado</span>
                  <span className="text-xl font-bold text-green-600">
                    {formatCurrency(dadosProjecao.reduce((sum, d) => sum + d.valor, 0))}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Status das Parcelas */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5 text-purple-600" />
              Status das Parcelas
            </CardTitle>
            <CardDescription>Distribuição atual das suas parcelas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-200">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4 rounded-full bg-yellow-500"></div>
                  <span className="font-medium text-yellow-800">Pendentes</span>
                </div>
                <p className="text-2xl font-bold text-yellow-700">{statusCount.pendente}</p>
                <p className="text-sm text-yellow-600">{formatCurrency(valorPendente)}</p>
              </div>

              <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4 rounded-full bg-green-500"></div>
                  <span className="font-medium text-green-800">Recebidas</span>
                </div>
                <p className="text-2xl font-bold text-green-700">{statusCount.recebida}</p>
                <p className="text-sm text-green-600">{formatCurrency(valorRecebido)}</p>
              </div>

              <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4 rounded-full bg-red-500"></div>
                  <span className="font-medium text-red-800">Atrasadas</span>
                </div>
                <p className="text-2xl font-bold text-red-700">{statusCount.atrasada}</p>
                <p className="text-sm text-red-600">Atenção!</p>
              </div>

              <div className="p-4 rounded-lg bg-gray-50 border border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4 rounded-full bg-gray-500"></div>
                  <span className="font-medium text-gray-800">Inadimplentes</span>
                </div>
                <p className="text-2xl font-bold text-gray-700">{statusCount.inadimplente}</p>
                <p className="text-sm text-gray-600">Perdidas</p>
              </div>
            </div>

            {totalParcelas > 0 && (
              <div className="mt-6 pt-4 border-t">
                <p className="text-sm text-muted-foreground mb-2">Taxa de Recebimento</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <ProgressBar 
                      value={statusCount.recebida} 
                      max={totalParcelas} 
                      color="bg-green-500" 
                    />
                  </div>
                  <span className="text-lg font-bold text-green-600">
                    {Math.round((statusCount.recebida / totalParcelas) * 100)}%
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Mensagem se não houver dados */}
        {!dadosVendas.length && !dadosProjecao.length && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BarChart3 className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center">
                Cadastre vendas para visualizar gráficos e análises
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
