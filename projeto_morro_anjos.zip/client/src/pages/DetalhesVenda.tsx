import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { toast } from "sonner";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString("pt-BR");
}

export default function DetalhesVenda() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/vendas/:id");
  const vendaId = params?.id ? parseInt(params.id) : 0;
  const utils = trpc.useUtils();

  const { data: venda, isLoading } = trpc.vendas.getById.useQuery({ id: vendaId });
  const { data: parcelas } = trpc.parcelas.getByVenda.useQuery({ vendaId });

  const marcarRecebidaMutation = trpc.parcelas.marcarRecebida.useMutation({
    onSuccess: () => {
      toast.success("Parcela marcada como recebida!");
      utils.parcelas.getByVenda.invalidate({ vendaId });
      utils.dashboard.estatisticas.invalidate();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <div className="h-8 w-64 bg-muted animate-pulse rounded" />
          <Card>
            <CardHeader>
              <div className="h-6 w-48 bg-muted animate-pulse rounded" />
            </CardHeader>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  if (!venda) {
    return (
      <DashboardLayout>
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Venda não encontrada</p>
            <Button className="mt-4" onClick={() => navigate("/vendas")}>
              Voltar para Vendas
            </Button>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/vendas")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{venda.codigo}</h1>
            {venda.clienteNome && (
              <p className="text-muted-foreground mt-1">{venda.clienteNome}</p>
            )}
          </div>
          <Badge
            className="ml-auto"
            variant={
              venda.status === "ativa"
                ? "default"
                : venda.status === "concluida"
                ? "secondary"
                : "destructive"
            }
          >
            {venda.status}
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(venda.valorTotal)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Comissão Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(venda.valorComissaoTotal)}</p>
              <p className="text-xs text-muted-foreground mt-1">2% do valor vendido</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Parcelamento</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{venda.parcelasEntrada}x</p>
              <p className="text-xs text-muted-foreground mt-1">
                {venda.percentualEntrada}% de entrada
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Data da Venda</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatDate(venda.dataVenda)}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Parcelas de Comissão</CardTitle>
            <CardDescription>Acompanhe o recebimento de cada parcela</CardDescription>
          </CardHeader>
          <CardContent>
            {parcelas && parcelas.length > 0 ? (
              <div className="space-y-3">
                {parcelas.map((parcela) => (
                  <div
                    key={parcela.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-10 h-10 rounded-full bg-muted">
                        <span className="font-semibold">{parcela.numeroParcela}</span>
                      </div>
                      <div>
                        <p className="font-semibold">{formatCurrency(parcela.valorParcela)}</p>
                        <p className="text-sm text-muted-foreground">
                          Vencimento: {formatDate(parcela.dataVencimento)}
                        </p>
                        {parcela.dataRecebimento && (
                          <p className="text-sm text-green-600">
                            Recebido em: {formatDate(parcela.dataRecebimento)}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          parcela.status === "recebida"
                            ? "default"
                            : parcela.status === "atrasada"
                            ? "destructive"
                            : "secondary"
                        }
                      >
                        {parcela.status}
                      </Badge>
                      {parcela.status === "pendente" && (
                        <Button
                          size="sm"
                          onClick={() => marcarRecebidaMutation.mutate({ id: parcela.id })}
                          disabled={marcarRecebidaMutation.isPending}
                        >
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Marcar como Recebida
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                Nenhuma parcela encontrada
              </p>
            )}
          </CardContent>
        </Card>

        {venda.observacoes && (
          <Card>
            <CardHeader>
              <CardTitle>Observações</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap">{venda.observacoes}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
