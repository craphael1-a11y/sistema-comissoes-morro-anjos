import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, Edit } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString("pt-BR");
}

export default function Vendas() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const { data: vendas, isLoading } = trpc.vendas.list.useQuery();
  const [vendaToDelete, setVendaToDelete] = useState<number | null>(null);
  const utils = trpc.useUtils();
  
  const deleteMutation = trpc.vendas.delete.useMutation({
    onSuccess: () => {
      toast.success("Venda excluída com sucesso!");
      utils.vendas.list.invalidate();
      setVendaToDelete(null);
    },
    onError: () => {
      toast.error("Erro ao excluir venda");
    },
  });

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 px-2 sm:px-0">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Vendas</h1>
            <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base">
              Gerencie todas as vendas de timeshare
            </p>
          </div>
          <Button onClick={() => navigate("/vendas/nova")} className="w-full sm:w-auto">
            <Plus className="mr-2 h-4 w-4" />
            Nova Venda
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="h-6 w-48 bg-muted animate-pulse rounded" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : vendas && vendas.length > 0 ? (
          <div className="space-y-4">
            {vendas.map((venda) => (
              <Card key={venda.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-xl">{venda.codigo}</CardTitle>
                      {venda.clienteNome && (
                        <CardDescription className="mt-1">{venda.clienteNome}</CardDescription>
                      )}
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Badge
                        variant={
                          venda.status === "ativa"
                            ? "default"
                            : venda.status === "concluida"
                            ? "secondary"
                            : "destructive"
                        }
                        className="whitespace-nowrap"
                      >
                        {venda.status}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-9 w-9 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-100"
                        title="Editar venda"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/vendas/${venda.id}/editar`);
                        }}
                      >
                        <Edit className="h-5 w-5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-9 w-9 p-0 text-destructive hover:text-red-700 hover:bg-red-100"
                        title="Excluir venda"
                        onClick={(e) => {
                          e.stopPropagation();
                          setVendaToDelete(venda.id);
                        }}
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent
                  className="cursor-pointer"
                  onClick={() => navigate(`/vendas/${venda.id}`)}
                >
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-4">
                    <div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Valor Total</p>
                      <p className="font-semibold text-sm sm:text-base">{formatCurrency(venda.valorTotal)}</p>
                    </div>
                    <div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Comissão</p>
                      <p className="font-semibold text-sm sm:text-base">{formatCurrency(venda.valorComissaoTotal)}</p>
                    </div>
                    <div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Parcelas</p>
                      <p className="font-semibold text-sm sm:text-base">{venda.parcelasEntrada}x</p>
                    </div>
                    <div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Data da Venda</p>
                      <p className="font-semibold text-sm sm:text-base">{formatDate(venda.dataVenda)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground mb-4">Nenhuma venda cadastrada ainda</p>
              <Button onClick={() => navigate("/vendas/nova")}>
                <Plus className="mr-2 h-4 w-4" />
                Cadastrar Primeira Venda
              </Button>
            </CardContent>
          </Card>
        )}

        <AlertDialog open={vendaToDelete !== null} onOpenChange={() => setVendaToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir esta venda? Esta ação não pode ser desfeita e todas as parcelas relacionadas também serão excluídas.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={() => {
                  if (vendaToDelete) {
                    deleteMutation.mutate({ id: vendaToDelete });
                  }
                }}
              >
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
