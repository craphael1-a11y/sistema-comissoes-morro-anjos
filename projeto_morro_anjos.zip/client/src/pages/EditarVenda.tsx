import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { ArrowLeft } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { toast } from "sonner";
import { useState } from "react";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

function formatDate(date: Date): string {
  const d = new Date(date);
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const year = d.getFullYear();
  return `${year}-${month}-${day}`;
}

export default function EditarVenda() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/vendas/:id/editar");
  const vendaId = params?.id ? parseInt(params.id) : 0;
  const utils = trpc.useUtils();

  const { data: venda, isLoading } = trpc.vendas.getById.useQuery({ id: vendaId });
  const [formData, setFormData] = useState<{
    codigo: string;
    clienteNome: string;
    valorTotal: string;
    cargo: "gerente" | "consultor" | "supervisor" | "promotor";
    parcelasEntrada: string;
    dataVenda: string;
    observacoes: string;
  }>({
    codigo: "",
    clienteNome: "",
    valorTotal: "",
    cargo: "consultor",
    parcelasEntrada: "1",
    dataVenda: "",
    observacoes: "",
  });

  const updateMutation = trpc.vendas.update.useMutation({
    onSuccess: () => {
      toast.success("Venda atualizada com sucesso!");
      utils.vendas.list.invalidate();
      utils.vendas.getById.invalidate({ id: vendaId });
      utils.dashboard.estatisticas.invalidate();
      navigate("/vendas");
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  // Preenche o formulário quando os dados da venda são carregados
  if (venda && !formData.codigo) {
    setFormData({
      codigo: venda.codigo,
      clienteNome: venda.clienteNome || "",
      valorTotal: String(venda.valorTotal),
      cargo: venda.cargo,
      parcelasEntrada: String(venda.parcelasEntrada),
      dataVenda: formatDate(venda.dataVenda),
      observacoes: venda.observacoes || "",
    });
  }

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <div className="h-8 w-64 bg-muted animate-pulse rounded" />
          <Card>
            <CardHeader>
              <div className="h-6 w-48 bg-muted animate-pulse rounded" />
            </CardHeader>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  if (!venda) {
    return (
      <DashboardLayout>
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Venda não encontrada</p>
            <Button className="mt-4" onClick={() => navigate("/vendas")}>
              Voltar para Vendas
            </Button>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const [year, month, day] = formData.dataVenda.split("-");
    const dataVenda = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));

    updateMutation.mutate({
      id: vendaId,
      codigo: formData.codigo,
      clienteNome: formData.clienteNome,
      valorTotal: parseInt(formData.valorTotal),
      cargo: formData.cargo,
      parcelasEntrada: parseInt(formData.parcelasEntrada),
      dataVenda,
      observacoes: formData.observacoes,
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 px-2 sm:px-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/vendas")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Editar Venda</h1>
            <p className="text-muted-foreground mt-1">Atualize os dados da venda {venda.codigo}</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informações da Venda</CardTitle>
            <CardDescription>Modifique os dados da venda conforme necessário</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="codigo">Código do Contrato</Label>
                  <Input
                    id="codigo"
                    value={formData.codigo}
                    onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="clienteNome">Nome do Cliente</Label>
                  <Input
                    id="clienteNome"
                    value={formData.clienteNome}
                    onChange={(e) => setFormData({ ...formData, clienteNome: e.target.value })}
                    placeholder="Nome do cliente"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="valorTotal">Valor Total da Venda (R$)</Label>
                  <Input
                    id="valorTotal"
                    type="number"
                    value={formData.valorTotal}
                    onChange={(e) => setFormData({ ...formData, valorTotal: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cargo">Cargo</Label>
                  <Select value={formData.cargo} onValueChange={(value) => setFormData({ ...formData, cargo: value as "gerente" | "consultor" | "supervisor" | "promotor" })}>
                    <SelectTrigger id="cargo">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gerente">Gerente (1%)</SelectItem>
                      <SelectItem value="consultor">Consultor (2%)</SelectItem>
                      <SelectItem value="supervisor">Supervisor (2%)</SelectItem>
                      <SelectItem value="promotor">Promotor (1.5%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="parcelasEntrada">Número de Parcelas</Label>
                  <Select value={formData.parcelasEntrada} onValueChange={(value) => setFormData({ ...formData, parcelasEntrada: value })}>
                    <SelectTrigger id="parcelasEntrada">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                        <SelectItem key={n} value={String(n)}>
                          {n}x
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataVenda">Data da Venda</Label>
                  <Input
                    id="dataVenda"
                    type="date"
                    value={formData.dataVenda}
                    onChange={(e) => setFormData({ ...formData, dataVenda: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  placeholder="Adicione observações sobre esta venda..."
                  rows={4}
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/vendas")}
                  className="w-full sm:w-auto"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="w-full sm:w-auto"
                >
                  {updateMutation.isPending ? "Atualizando..." : "Atualizar Venda"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Resumo da Comissão</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Valor Total:</span>
                <span className="font-semibold">{formatCurrency(parseInt(formData.valorTotal) || 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Comissão Total:</span>
                <span className="font-semibold">
                  {formatCurrency(Math.round((parseInt(formData.valorTotal) || 0) * ((formData.cargo as string) === "gerente" ? 100 : (formData.cargo as string) === "promotor" ? 150 : 200)) / 10000)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Parcelas:</span>
                <span className="font-semibold">{formData.parcelasEntrada}x</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
