import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function NovaVenda() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const [formData, setFormData] = useState({
    codigo: "",
    clienteNome: "",
    cargo: "consultor" as "gerente" | "consultor" | "supervisor" | "promotor",
    valorTotal: "",
    percentualEntrada: "",
    parcelasEntrada: "",
    dataVenda: new Date().toISOString().split('T')[0], // Formato YYYY-MM-DD
    observacoes: "",
  });

  const createMutation = trpc.vendas.create.useMutation({
    onSuccess: () => {
      toast.success("Venda cadastrada com sucesso!");
      utils.vendas.list.invalidate();
      utils.dashboard.estatisticas.invalidate();
      navigate("/vendas");
    },
    onError: (error) => {
      toast.error(`Erro ao cadastrar venda: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const valorTotal = Math.round(parseFloat(formData.valorTotal) * 100);
    const percentualEntrada = parseInt(formData.percentualEntrada);
    const parcelasEntrada = parseInt(formData.parcelasEntrada);

    if (parcelasEntrada < 1 || parcelasEntrada > 10) {
      toast.error("O número de parcelas deve estar entre 1 e 10");
      return;
    }

    // Converte a data string (YYYY-MM-DD) para Date no timezone local
    // Evita o problema de timezone onde 01/12 vira 30/11
    const [year, month, day] = formData.dataVenda.split('-').map(Number);
    const dataVenda = new Date(year, month - 1, day);
    
    createMutation.mutate({
      codigo: formData.codigo,
      clienteNome: formData.clienteNome || undefined,
      cargo: formData.cargo,
      valorTotal,
      percentualEntrada,
      parcelasEntrada,
      dataVenda,
      observacoes: formData.observacoes || undefined,
    });
  };

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="max-w-3xl space-y-6 px-2 sm:px-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Nova Venda</h1>
          <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base">
            Cadastre uma nova venda de timeshare
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informações da Venda</CardTitle>
            <CardDescription>
              Preencha os dados da venda para calcular automaticamente as comissões
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="codigo">Código da Venda *</Label>
                  <Input
                    id="codigo"
                    required
                    value={formData.codigo}
                    onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
                    placeholder="Ex: VND-2024-001"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="clienteNome">Nome do Cliente</Label>
                  <Input
                    id="clienteNome"
                    value={formData.clienteNome}
                    onChange={(e) => setFormData({ ...formData, clienteNome: e.target.value })}
                    placeholder="Opcional"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cargo">Cargo do Vendedor *</Label>
                  <select
                    id="cargo"
                    required
                    value={formData.cargo}
                    onChange={(e) => setFormData({ ...formData, cargo: e.target.value as any })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="gerente">Gerente (1%)</option>
                    <option value="consultor">Consultor (2%)</option>
                    <option value="supervisor">Supervisor (2%)</option>
                    <option value="promotor">Promotor (1,5%)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataVenda">Data da Venda *</Label>
                  <Input
                    id="dataVenda"
                    type="date"
                    required
                    value={formData.dataVenda}
                    onChange={(e) => setFormData({ ...formData, dataVenda: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="valorTotal">Valor Total (R$) *</Label>
                  <Input
                    id="valorTotal"
                    type="number"
                    step="0.01"
                    required
                    value={formData.valorTotal}
                    onChange={(e) => setFormData({ ...formData, valorTotal: e.target.value })}
                    placeholder="100000.00"
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="percentualEntrada">% Entrada *</Label>
                  <Input
                    id="percentualEntrada"
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={formData.percentualEntrada}
                    onChange={(e) => setFormData({ ...formData, percentualEntrada: e.target.value })}
                    placeholder="17"
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="parcelasEntrada">Parcelas (1-10) *</Label>
                  <Input
                    id="parcelasEntrada"
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.parcelasEntrada}
                    onChange={(e) => setFormData({ ...formData, parcelasEntrada: e.target.value })}
                    placeholder="5"
                    className="text-base"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  placeholder="Informações adicionais sobre a venda..."
                  rows={4}
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                <Button type="submit" disabled={createMutation.isPending} className="w-full sm:w-auto">
                  {createMutation.isPending ? "Cadastrando..." : "Cadastrar Venda"}
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate("/vendas")} className="w-full sm:w-auto">
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="text-base">Informações Importantes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>• A comissão será calculada automaticamente como 2% do valor total</p>
            <p>• O número de parcelas da comissão será igual ao número de parcelas da entrada</p>
            <p>• As parcelas terão vencimento mensal a partir da data da venda</p>
            <p>• Você poderá acompanhar o status de cada parcela na tela de detalhes</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
