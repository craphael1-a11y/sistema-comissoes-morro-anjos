import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { TrendingUp } from "lucide-react";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value / 100);
}

export default function Relatorios() {
  const { user, loading } = useAuth();
  const { data: vendas, isLoading: vendLoading } = trpc.vendas.list.useQuery();
  const { data: parcelas, isLoading: parcelLoading } = trpc.parcelas.listPendentes.useQuery();

  if (loading || !user) {
    return <DashboardLayout><div>Carregando...</div></DashboardLayout>;
  }

  if (vendLoading || parcelLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <div className="h-6 w-48 bg-muted animate-pulse rounded" />
              </CardHeader>
            </Card>
          ))}
        </div>
      </DashboardLayout>
    );
  }

  // Preparar dados para tabelas
  const vendasPorMes: Record<string, { mes: string; vendas: number; comissoes: number; quantidade: number }> = {};
  
  if (vendas) {
    vendas.forEach((venda) => {
      const data = new Date(venda.dataVenda);
      const mes = data.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
      const chave = mes;

      if (!vendasPorMes[chave]) {
        vendasPorMes[chave] = { mes, vendas: 0, comissoes: 0, quantidade: 0 };
      }

      vendasPorMes[chave].vendas += venda.valorTotal;
      vendasPorMes[chave].comissoes += venda.valorComissaoTotal;
      vendasPorMes[chave].quantidade += 1;
    });
  }

  const dadosVendas = Object.values(vendasPorMes).sort((a, b) => {
    const [mesA, anoA] = a.mes.split(" ");
    const [mesB, anoB] = b.mes.split(" ");
    if (anoA !== anoB) return parseInt(anoA) - parseInt(anoB);
    const meses = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
    return meses.indexOf(mesA.toLowerCase()) - meses.indexOf(mesB.toLowerCase());
  });

  // Dados de status de parcelas
  const statusCount: Record<string, number> = {
    "Pendente": 0,
    "Recebida": 0,
    "Atrasada": 0,
    "Inadimplente": 0,
  };

  if (parcelas) {
    parcelas.forEach((p) => {
      if (p.status === "recebida") statusCount["Recebida"]++;
      else if (p.status === "atrasada") statusCount["Atrasada"]++;
      else if (p.status === "inadimplente") statusCount["Inadimplente"]++;
      else statusCount["Pendente"]++;
    });
  }

  // Dados de cargo
  const cargoCount: Record<string, { quantidade: number; comissoes: number }> = {
    "Gerente": { quantidade: 0, comissoes: 0 },
    "Consultor": { quantidade: 0, comissoes: 0 },
    "Supervisor": { quantidade: 0, comissoes: 0 },
    "Promotor": { quantidade: 0, comissoes: 0 },
  };

  if (vendas) {
    vendas.forEach((venda) => {
      const cargoLabel = venda.cargo === "gerente" ? "Gerente" :
                        venda.cargo === "consultor" ? "Consultor" :
                        venda.cargo === "supervisor" ? "Supervisor" : "Promotor";
      cargoCount[cargoLabel].quantidade++;
      cargoCount[cargoLabel].comissoes += venda.valorComissaoTotal;
    });
  }

  const dadosCargo = Object.entries(cargoCount)
    .filter(([, data]) => data.quantidade > 0)
    .map(([name, data]) => ({ name, quantidade: data.quantidade, comissoes: data.comissoes }));

  // Totais
  const totalVendido = vendas?.reduce((sum, v) => sum + v.valorTotal, 0) || 0;
  const totalComissoes = vendas?.reduce((sum, v) => sum + v.valorComissaoTotal, 0) || 0;
  const totalParcelas = parcelas?.length || 0;
  const parcelasRecebidas = parcelas?.filter(p => p.status === "recebida").length || 0;

  return (
    <DashboardLayout>
      <div className="space-y-6 px-2 sm:px-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Relatórios</h1>
          <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base">
            Análises e dados de desempenho
          </p>
        </div>

        {/* Cards de Resumo */}
        <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Vendido</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalVendido)}</div>
              <p className="text-xs text-muted-foreground mt-1">{vendas?.length || 0} vendas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Comissões Totais</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(totalComissoes)}</div>
              <p className="text-xs text-muted-foreground mt-1">Sobre vendas ativas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Parcelas Recebidas</CardTitle>
              <TrendingUp className="h-4 w-4 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">{parcelasRecebidas}</div>
              <p className="text-xs text-muted-foreground mt-1">De {totalParcelas} parcelas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Recebimento</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {totalParcelas > 0 ? Math.round((parcelasRecebidas / totalParcelas) * 100) : 0}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">Parcelas recebidas</p>
            </CardContent>
          </Card>
        </div>

        {/* Status de Parcelas */}
        <Card>
          <CardHeader>
            <CardTitle>Status das Parcelas</CardTitle>
            <CardDescription>Distribuição de parcelas por status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <span className="text-sm font-medium">Pendentes</span>
                </div>
                <span className="text-sm font-bold">{statusCount["Pendente"]}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm font-medium">Recebidas</span>
                </div>
                <span className="text-sm font-bold">{statusCount["Recebida"]}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-sm font-medium">Atrasadas</span>
                </div>
                <span className="text-sm font-bold">{statusCount["Atrasada"]}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                  <span className="text-sm font-medium">Inadimplentes</span>
                </div>
                <span className="text-sm font-bold">{statusCount["Inadimplente"]}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabela de Resumo Mensal */}
        {dadosVendas.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Resumo Mensal Detalhado</CardTitle>
              <CardDescription>Detalhes de vendas, comissões e quantidade por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-4 font-semibold">Mês</th>
                      <th className="text-right py-2 px-4 font-semibold">Quantidade</th>
                      <th className="text-right py-2 px-4 font-semibold">Total Vendido</th>
                      <th className="text-right py-2 px-4 font-semibold">Comissões</th>
                      <th className="text-right py-2 px-4 font-semibold">Ticket Médio</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dadosVendas.map((row, idx) => (
                      <tr key={idx} className="border-b hover:bg-muted/50">
                        <td className="py-2 px-4">{row.mes}</td>
                        <td className="text-right py-2 px-4">{row.quantidade}</td>
                        <td className="text-right py-2 px-4 font-medium">{formatCurrency(row.vendas)}</td>
                        <td className="text-right py-2 px-4 font-medium text-green-600">{formatCurrency(row.comissoes)}</td>
                        <td className="text-right py-2 px-4">{formatCurrency(row.vendas / row.quantidade)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabela de Análise por Cargo */}
        {dadosCargo.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Análise por Cargo</CardTitle>
              <CardDescription>Vendas e comissões por cargo do vendedor</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-4 font-semibold">Cargo</th>
                      <th className="text-right py-2 px-4 font-semibold">Quantidade</th>
                      <th className="text-right py-2 px-4 font-semibold">Total Comissões</th>
                      <th className="text-right py-2 px-4 font-semibold">Comissão Média</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dadosCargo.map((row, idx) => (
                      <tr key={idx} className="border-b hover:bg-muted/50">
                        <td className="py-2 px-4 font-medium">{row.name}</td>
                        <td className="text-right py-2 px-4">{row.quantidade}</td>
                        <td className="text-right py-2 px-4 font-medium text-green-600">{formatCurrency(row.comissoes)}</td>
                        <td className="text-right py-2 px-4">{formatCurrency(row.comissoes / row.quantidade)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {!dadosVendas.length && !dadosCargo.length && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground">Nenhum dado disponível para exibir relatórios</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
