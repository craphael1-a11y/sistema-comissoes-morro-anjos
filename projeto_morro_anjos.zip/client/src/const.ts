export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const APP_TITLE = import.meta.env.VITE_APP_TITLE || "Morro dos Anjos";

export const APP_LOGO = "/logo-morro-anjos.png";
