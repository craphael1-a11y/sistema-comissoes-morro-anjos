import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Vendas from "./pages/Vendas";
import NovaVenda from "./pages/NovaVenda";
import DetalhesVenda from "./pages/DetalhesVenda";
import EditarVenda from "./pages/EditarVenda";
import Comissoes from "./pages/Comissoes";
import Graficos from "./pages/Graficos";
import Relatorios from "./pages/Relatorios";
import Carteira from "./pages/Carteira";
import Login from "./pages/Login";
import Registro from "./pages/Registro";


function Router() {
  return (
    <Switch>
      <Route path={"/login"} component={Login} />
      <Route path={"/registro"} component={Registro} />
      <Route path={"/"} component={Dashboard} />
      <Route path={"/vendas"} component={Vendas} />
      <Route path={"/vendas/nova"} component={NovaVenda} />
      <Route path={"/vendas/:id/editar"} component={EditarVenda} />
      <Route path={"/vendas/:id"} component={DetalhesVenda} />
      <Route path={"/comissoes"} component={Comissoes} />
      <Route path={"/graficos"} component={Graficos} />
      <Route path={"/relatorios"} component={Relatorios} />
      <Route path={"/carteira"} component={Carteira} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
