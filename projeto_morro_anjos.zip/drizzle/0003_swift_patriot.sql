ALTER TABLE `vendas` MODIFY COLUMN `taxaComissao` int NOT NULL;--> statement-breakpoint
ALTER TABLE `vendas` ADD `cargo` enum('gerente','consultor','supervisor','promotor') NOT NULL;