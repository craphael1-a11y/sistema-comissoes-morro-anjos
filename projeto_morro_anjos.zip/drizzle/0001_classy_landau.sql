CREATE TABLE `parcelas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vendaId` int NOT NULL,
	`numeroParcela` int NOT NULL,
	`valorParcela` int NOT NULL,
	`dataVencimento` timestamp NOT NULL,
	`dataRecebimento` timestamp,
	`status` enum('pendente','recebida','atrasada') NOT NULL DEFAULT 'pendente',
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `parcelas_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vendas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codigo` varchar(50) NOT NULL,
	`clienteNome` varchar(255),
	`valorTotal` int NOT NULL,
	`percentualEntrada` int NOT NULL,
	`parcelasEntrada` int NOT NULL,
	`taxaComissao` int NOT NULL DEFAULT 200,
	`valorComissaoTotal` int NOT NULL,
	`status` enum('ativa','cancelada','concluida') NOT NULL DEFAULT 'ativa',
	`dataVenda` timestamp NOT NULL,
	`observacoes` text,
	`usuarioId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vendas_id` PRIMARY KEY(`id`),
	CONSTRAINT `vendas_codigo_unique` UNIQUE(`codigo`)
);
