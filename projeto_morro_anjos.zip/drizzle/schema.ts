import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** Nome de usuário único para login */
  username: varchar("username", { length: 50 }).notNull().unique(),
  /** Hash da senha do usuário */
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  /** Nome completo do colaborador */
  name: varchar("name", { length: 255 }).notNull(),
  /** Email opcional */
  email: varchar("email", { length: 320 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  /** Campos legados do OAuth - manter para compatibilidade */
  openId: varchar("openId", { length: 64 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Vendas de timeshare
 */
export const vendas = mysqlTable("vendas", {
  id: int("id").autoincrement().primaryKey(),
  /** Código único da venda para referência */
  codigo: varchar("codigo", { length: 50 }).notNull().unique(),
  /** Nome do cliente (opcional, foco em métricas) */
  clienteNome: varchar("clienteNome", { length: 255 }),
  /** Valor total da venda em centavos (ex: R$ 100.000,00 = 10000000) */
  valorTotal: int("valorTotal").notNull(),
  /** Percentual de entrada dado pelo cliente (ex: 17 para 17%) */
  percentualEntrada: int("percentualEntrada").notNull(),
  /** Número de parcelas da entrada (1 a 10) */
  parcelasEntrada: int("parcelasEntrada").notNull(),
  /** Cargo do vendedor que define a taxa de comissão */
  cargo: mysqlEnum("cargo", ["gerente", "consultor", "supervisor", "promotor"]).notNull(),
  /** Taxa de comissão aplicada (baseada no cargo: gerente=1%, consultor/supervisor=2%, promotor=1.5%) */
  taxaComissao: int("taxaComissao").notNull(),
  /** Valor total da comissão em centavos */
  valorComissaoTotal: int("valorComissaoTotal").notNull(),
  /** Status da venda */
  status: mysqlEnum("status", ["ativa", "cancelada", "concluida"]).default("ativa").notNull(),
  /** Data da venda */
  dataVenda: timestamp("dataVenda").notNull(),
  /** Observações adicionais */
  observacoes: text("observacoes"),
  /** Usuário que registrou a venda */
  usuarioId: int("usuarioId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Venda = typeof vendas.$inferSelect;
export type InsertVenda = typeof vendas.$inferInsert;

/**
 * Parcelas de comissão
 */
export const parcelas = mysqlTable("parcelas", {
  id: int("id").autoincrement().primaryKey(),
  /** ID da venda relacionada */
  vendaId: int("vendaId").notNull(),
  /** Número da parcela (1, 2, 3...) */
  numeroParcela: int("numeroParcela").notNull(),
  /** Valor da parcela em centavos */
  valorParcela: int("valorParcela").notNull(),
  /** Data prevista de recebimento */
  dataVencimento: timestamp("dataVencimento").notNull(),
  /** Data efetiva de recebimento */
  dataRecebimento: timestamp("dataRecebimento"),
  /** Status da parcela */
  status: mysqlEnum("status", ["pendente", "recebida", "atrasada", "cancelada", "inadimplente"]).default("pendente").notNull(),
  /** Observações sobre a parcela */
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Parcela = typeof parcelas.$inferSelect;
export type InsertParcela = typeof parcelas.$inferInsert;

/**
 * Metas mensais de vendas
 */
export const metas = mysqlTable("metas", {
  id: int("id").autoincrement().primaryKey(),
  /** Usuário dono da meta */
  usuarioId: int("usuarioId").notNull(),
  /** Mês da meta (1-12) */
  mes: int("mes").notNull(),
  /** Ano da meta */
  ano: int("ano").notNull(),
  /** Meta de valor vendido em centavos */
  metaVendas: int("metaVendas").notNull(),
  /** Meta de quantidade de vendas */
  metaQuantidade: int("metaQuantidade").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Meta = typeof metas.$inferSelect;
export type InsertMeta = typeof metas.$inferInsert;
